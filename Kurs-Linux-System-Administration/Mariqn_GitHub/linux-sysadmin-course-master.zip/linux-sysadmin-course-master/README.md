linux-sysadmin-course
=====================

Linux System Administration 101

This repo includes additional materials and presentations for the course.

It also includes home works.


Grades:
* Exam - 60% 
* Homeworks - 15%
* Peer review - 15%
* Attendance - 10%

* Bonuses - max 20%

Bonuses are gained from the forums and extraordanary good homeworks.
  
