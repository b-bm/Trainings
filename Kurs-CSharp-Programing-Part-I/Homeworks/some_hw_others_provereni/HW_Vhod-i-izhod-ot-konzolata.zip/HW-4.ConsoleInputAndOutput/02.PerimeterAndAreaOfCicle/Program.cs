﻿using System;

class Program
{
    static void Main()
    {
        //Write a program that reads the radius r of a circle and prints its perimeter and area
        Console.Write("Write radius of a circle r = ");
        string line = Console.ReadLine();
        double r = double.Parse(line);

        double perimeter = 2 * r * Math.PI;
        double area = Math.Pow(r, 2) * Math.PI;
        Console.WriteLine("Perimeter = {0:0.00}", perimeter);
        Console.WriteLine("Area = {0:0.00}", area);
    }
}

