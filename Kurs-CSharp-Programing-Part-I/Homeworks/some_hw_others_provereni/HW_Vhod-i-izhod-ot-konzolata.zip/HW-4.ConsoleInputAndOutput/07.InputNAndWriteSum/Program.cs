﻿using System;

class Program
{
    static void Main()
    {
        // Write a program that gets a number n and after that gets more n numbers and calculates and prints their sum. 
        
        int n = int.Parse(Console.ReadLine());
        double sum = 0;
        for (int i = 0; i < n; i++)
        {
            double numbers = double.Parse(Console.ReadLine());
            sum += numbers;
        }
                   
    }
}

