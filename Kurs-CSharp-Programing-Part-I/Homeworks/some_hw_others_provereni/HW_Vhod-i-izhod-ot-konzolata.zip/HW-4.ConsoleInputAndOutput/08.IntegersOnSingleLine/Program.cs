﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Please enter an integer number n");
        int n = int.Parse(Console.ReadLine());
        for (int i = 1; i <= n; i++) //using a for loop that will repeat n number of times until i is less than or equal to n
        {
            Console.Write(i);
        }
     }
}

