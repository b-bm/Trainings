﻿using System;

class Program
{
    static void Main()
    {
        //A company has name, address, phone number, fax number, web site and manager. 
        //The manager has first name, last name, age and a phone number. 
        //Write a program that reads the information about a company and its manager and prints them on the console.
        
        Console.WriteLine("Please enter the company's name:");
        string companyName = Console.ReadLine();
        Console.WriteLine("Please enter the company's address:");
        string companyAddress = Console.ReadLine();
        Console.WriteLine("Please enter the company's phone number");
        long companyPhone = long.Parse(Console.ReadLine());
        Console.WriteLine("Please enter the company fax number:");
        long companyFax = long.Parse(Console.ReadLine());
        Console.WriteLine("Please enter the company's website");
        string website = Console.ReadLine();
        Console.WriteLine("Please enter the company's manager name");
        string managerName = Console.ReadLine();
        Console.WriteLine("Please enter the manager's first name:");
        string firstName = Console.ReadLine();
        Console.WriteLine("Please enter the manager's last name:");
        string lastName = Console.ReadLine();
        Console.WriteLine("Please enter the manager's age");
        byte age = byte.Parse(Console.ReadLine());
        Console.WriteLine("Please enter the manager's phone number:");
        long managerPhone = long.Parse(Console.ReadLine());
        Console.WriteLine("Company's Name: {0}", companyName);
        Console.WriteLine("Company's Address: {0}", companyAddress);
        Console.WriteLine("Company's Phone {0}", companyPhone);
        Console.WriteLine("Company's Fax {0}", companyFax);
        Console.WriteLine("Company's Website {0}", website);
        Console.WriteLine("Manager's name {0}", managerName);
        Console.WriteLine("Manager's first name {0}", firstName);
        Console.WriteLine("Manager's last name {0}", lastName);
        Console.WriteLine("Manager's age {0}", age);
        Console.WriteLine("Manager's Phone {0}", managerPhone);
    }
}

