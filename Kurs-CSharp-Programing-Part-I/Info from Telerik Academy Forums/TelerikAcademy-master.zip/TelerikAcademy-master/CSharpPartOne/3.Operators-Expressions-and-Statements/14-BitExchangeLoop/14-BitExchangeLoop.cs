﻿// 14. * Write a program that exchanges bits {p, p+1, …, p+k-1) with bits {q, q+1, …, q+k-1} of given 32-bit unsigned integer.

using System;

class ExchangeBitsFirst
{
    static void Main()
    {
        // Sorry - Too hard for me :(
    }
}