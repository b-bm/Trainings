﻿// 3. Modify the application to print your name.

using System;

class PrintMyName
{
    static void Main()
    {
        Console.WriteLine("Ivan Ivanov");
    }
}
