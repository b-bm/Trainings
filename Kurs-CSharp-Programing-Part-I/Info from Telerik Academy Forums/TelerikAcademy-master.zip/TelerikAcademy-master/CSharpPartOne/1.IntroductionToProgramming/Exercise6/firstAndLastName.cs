﻿// 6. Create console application that prints your first and last name.

using System;

class firstAndLastName
{
    static void Main()
    {
        string firstName = "Ivan";
        string lastName = "Ivanov";
        Console.WriteLine("My first name is {0} and my last name is {1}.", firstName, lastName);
    }
}
