﻿// 8. Create a console application that calculates and prints the square of the number 12345.

using System;

class Square
{
    static void Main()
    {
        int number = 12345;
        int squareNumber = number*number;
        Console.WriteLine("The square of number {0} is {1}",number, squareNumber);
    }
}
