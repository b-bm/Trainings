﻿// 7. Create a console application that prints the current date and time.

using System;

class CurrentDate
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}
