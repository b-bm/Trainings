﻿// 4. Declare an integer variable and assign it with the value 254 in hexadecimal format. Use Windows Calculator to find its hexadecimal representation.

using System;

class HexVariable
{
    static void Main()
    {
        int numberInHex = 0xFE;
        Console.WriteLine("This is an int variable with Hex Value: {0}",numberInHex);
    }
}

