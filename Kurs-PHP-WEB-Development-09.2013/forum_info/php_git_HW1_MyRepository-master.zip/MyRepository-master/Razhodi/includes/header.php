<?php
require 'constants.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $pageTitle;?></title>

        <meta charset="UTF-8">       
    </head>
    <body>