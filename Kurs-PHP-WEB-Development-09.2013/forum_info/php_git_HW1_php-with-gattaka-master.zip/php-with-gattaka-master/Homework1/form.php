<?php
mb_internal_encoding('UTF-8');
$pageTitle = 'Добави разход';
require 'incl/utils.php'; 
include 'incl/header.php';
if ($_POST) {
	writeInfo();
}
?>
<a href='/Homework1'>Обратно</a>
<form method='POST'>
	<table>
		<tr>
			<th>Име</th>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<th>Сума</th>
			<td><input type="text" name="cost"></td>	
		</tr>
		<tr>
			<th>Вид</th>
			<td>
				<select name='group'>
					<?php
						listGroups($groups);
					?>	
				</select>
			</td>
		</tr>
		<tr>
			<th>Добави дата</th>
			<td>
				<span>Ден:</span>
				<select name="day">
					<?php
						listValues(1, 31);
					?>
				</select>
				<span>Месец:</span>
				<select name="month">
					<?php
						listValues(1, 12);
					?>
				</select>
				<span>Година:</span>
				<select name="year">
					<?php
						listValues(2000, 2014);
					?>
				</select>
			</td>
		</tr>
	</table>
	<input type="submit" value="Добави">
	<em>
		<p>Остави стойностите за дата на нула и разхода ще бъде добавен с днешна такава.</p>
	</em>
</form>
<?php
include 'incl/footer.php';
