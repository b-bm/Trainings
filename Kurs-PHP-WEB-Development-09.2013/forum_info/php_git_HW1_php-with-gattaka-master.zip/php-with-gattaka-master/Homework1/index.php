<?php
require 'incl/utils.php'; 
$pageTitle = 'Списък';
include 'incl/header.php';
?>
<a href='form.php'>Добави нов разход</a>
<form>
	<select name="filter">
		<option>Всички</option>
		<?php 
			listGroups($groups);
		?>
	</select>
	<input type="submit" value="Филтрирай">
</form>
<table>
    <thead>
        <th>Дата</th>
        <th>Име</th>
        <th>Сума</th>
        <th>Вид</th>
    </thead>
    <tbody>
    <?php 
        readInfo();
    ?>
    </tbody>
    <tfoot>
    	<td></td>
    	<td></td>
    	<td><b><?= $allCost?></b></td>
    	<td></td>
    </tfoot>    
</table>
<?php
include 'incl/footer.php';

