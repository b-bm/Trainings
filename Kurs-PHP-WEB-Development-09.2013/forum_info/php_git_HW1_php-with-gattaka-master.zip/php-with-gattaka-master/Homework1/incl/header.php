<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?= $pageTitle;?></title>
    <style type="text/css">
    	body {
            font-family: monospace, sans-serif;
        }
        table {
    		border-radius: 3px;
    		border: 1px solid black;
    	}

    	input[type=text] {
    		width: 170px;

    	}
    	p {
    		font-size: 12px;
    	}

        .error {
            color: red;
        }

        .success {
            color: green;
        }
        td {
            padding: 5px;
        }
    </style>
</head>
<body>
