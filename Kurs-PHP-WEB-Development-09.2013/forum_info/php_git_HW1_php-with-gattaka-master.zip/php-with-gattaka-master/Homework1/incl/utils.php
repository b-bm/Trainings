<?php 

$groups = array(1 => 'Храна', 2 => 'Курви', 3 => 'Пиене', 4 => 'Други (маловажни) неща');
$allCost = 0;

// Some helper functions
function listGroups($gr) {
	foreach ($gr as $key => $value) {
			if ($key == $_GET['filter']) {
				echo '<option value="'.$key.'" selected = "selected">'.$value.'</option>';
			} else {
				echo '<option value="'.$key.'">'.$value.'</option>';
			}
	}
}

function listValues($start, $end) {
	/* Inputs must be natural numbers
	 * Assume: $start < $end
	 */
	echo "<option>0</option>";
	for ($i=$start; $i <= $end; $i++) { 
		echo '<option>'.$i.'</option>';
	}
}

function makeDate($day, $month, $year) {
	/* Makes a specific date
	 * Input: Natural, Natural, Natural
	 * Output: String in the form of:
	 *         dd.mm.yyyy
	 */
	if(checkdate($month, $day, $year)){
			if ($day < 10) {
				$day = '0'.$day;
			}
			if ($month < 10) {
				$month = '0'.$month;
			}
			return $day.'.'.$month.'.'.$year;
	} else {
		return NULL;
	}
}

// Here be dragons!
function writeInfo() {
	// first we format the information
	// into an appropriate state
	global $groups;
	$name = str_replace('!', '', trim($_POST['name']));
	$cost = str_replace('!', '', trim($_POST['cost']));
	$selectedGroup = (int)$_POST['group'];
	$day = $_POST['day'];
	$month = $_POST['month'];
	$year = $_POST['year'];
	$date = makeDate($day, $month, $year);
	// and then we validate it
	$haveError = false;
	if ($day == 0 and $month == 0 and $year == 0) {
		$date = date('d.m.Y');
	} else if (!$date){
		echo '<p class="error">Датата е невалидна!</p>';
		$haveError = true;
	}
	if(mb_strlen($name) < 3){
		echo '<p class="error">Името е твърде кратко!</p>';
		$haveError = true;
	}
	if((float)$cost <= 0){
		echo '<p class="error">Цената е невалидна!</p>';
		$haveError = true;
	}
	if(!array_key_exists($selectedGroup, $groups)){
		echo '<p class="error">Несъществуващ вид!</p>';
		$haveError = true;
	}
	// if there's not a single error, write the info
	if(!$haveError){
		$result=$date.'!'.$name.'!'.$cost.'!'.$selectedGroup."\n";
		if(file_put_contents('data.txt', $result, FILE_APPEND)){
			echo '<p class="success">СтанА!</p>';
		} else {
			echo '<p class="error">Нещо се прееба!</p>';
		}
	}
}

function readInfo() {
	if(file_exists('data.txt')){
		global $groups;
		global $allCost;
    	$result = file('data.txt');
    	// let's filter this motha'fucka
    	if (!$_GET) {
    		$filter = 'Всички';
    	} else {
    		$filter = $_GET['filter'];
    	}
    	
    	foreach ($result as $value) {
    		$columns = explode('!', $value);
    		if ($filter == (int)$columns[3] or $filter == 'Всички'){
    		    		$allCost += $columns[2];
    		    		echo '<tr>
    		    			      <td><em>'.$columns[0].'</em></td>
    		    			      <td>'.$columns[1].'</td>
    		    			      <td>'.$columns[2].'</td>
    		    			      <td>'.$groups[trim($columns[3])].'</td>
    		    		      </tr>';
    		    		  }
        	
      	
    	}
	}
}