<!DOCTYPE html>
<html>
<head>
	<title><?= $pageTitle; ?></title>
	<meta charset="UTF-8">
</head>
<body>
<?php 
error_reporting(0);
session_start();
?>