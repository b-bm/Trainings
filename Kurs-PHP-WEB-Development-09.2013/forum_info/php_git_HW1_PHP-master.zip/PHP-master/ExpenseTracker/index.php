<?php
$pageTitle = 'Списък с разходи';
include './includes/header.php';
require './includes/expenseTypes.php';
?>
<div>
    <a href="AddExpense.php" title="Добави нов разход">Добави нов разход</a>
    <form method="POST">
        <select name="filter" >
            <?php
            foreach ($expenseTypes as $key => $value) {
                echo '<option value="' . $key . '">' . $value . '</option>';
            }
            ?>
        </select> 
        <input type="submit" value="Филтрирай" />
    </form>
</div>
<table border="1">
    <thead>
        <tr>
            <th>Дата</th>
            <th>Име</th>
            <th>Сума</th>
            <th>Вид</th>
        </tr>
    </thead>

    <tbody>
        <tr> 
            <?php
            if (file_exists('record.txt')) {
                $recordedData = file('record.txt');
                if ($_POST) {
                    $selectedFilter = (int) $_POST['filter'];
                }
                foreach ($recordedData as $value) {
                    $colums = explode('!', $value);

                    if (($selectedFilter != 0) && ($selectedFilter != (trim($colums[3])))) {
                        continue;
                    }
                    echo '<tr>
        <td>' . $colums[0] . '</td>
        <td>' . $colums[1] . '</td>
        <td>' . $colums[2] . '</td>
        <td>' . $expenseTypes[trim($colums[3])] . '</td>
        </tr>';
                    $total+= $colums[2];
                }
            }
            ?>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="4">
                <?php
                echo'Общо: ' . $total . ' Лева';
                ?>
            </td>
        </tr>
    </tfoot>
</table>
<?php
include './includes/footer.php';
?>