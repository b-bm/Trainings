<?php
$pageTitle = 'Добави нов разход';
include './includes/header.php';
require './includes/expenseTypes.php';
$error = FALSE;

if ($_POST) {
    $date = date('d.m.Y');

    $name = trim($_POST['name']);
    $name = str_replace('!', '', $name);

    $cost = (trim($_POST['sum']));
    $cost = floatval(str_replace('!', '', $cost));

    $expenseGroup = (int) $_POST['expenses'];

    if ((mb_strlen($name) < 3) || (mb_strlen($name) > 100 )) {
        echo 'Името е прекалено късо(3 символа) или прекалено дълго(100 символа)';
        $error = true;
    }

    if ($cost <= 0) {
        echo 'Цената е прекалено малка';
        $error = true;
    }

    if (!array_key_exists($expenseGroup, $expenseTypes)) {
        $error = true;
    }

    if (!$error) {
        $record = $date . '!' . $name . '!' . $cost . '!' . $expenseGroup . "\n";
        file_put_contents('record.txt', $record, FILE_APPEND);
        echo "Успешен Запис";
    }
}
?>

<div>
    <a href="index.php" title="Списък с разходи">Списък с разходи</a>

    <form method="POST">
        <div>
            <label for="name">Име: </label>
            <input type="text" name="name">
        </div>
        <div>
            <label for="sum">Сума: </label>
            <input type="text" name="sum">
        </div>
        <div>
            <label for="expenses">Вид: </label>
            <select name="expenses" >
                <?php
                foreach ($expenseTypes as $key => $value) {
                    if ($key == 0) {
                        continue;
                    }
                    echo '<option value="' . $key . '">' . $value . '</option>';
                }
                ?>
            </select> 
        </div>
        <div>
            <input type="submit" name="add" value="Добави">
        </div>
    </form>
</div>
<?php
include './includes/footer.php';
?>