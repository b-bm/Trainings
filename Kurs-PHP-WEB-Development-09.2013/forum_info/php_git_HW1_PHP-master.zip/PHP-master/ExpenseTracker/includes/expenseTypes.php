<?php
mb_internal_encoding('UTF-8');

$expenseTypes = array(
    0 => 'Всички',
    1 => 'Храна',
    2 => 'Облекло',
    3 => 'Транспорт',
    4 => 'Обучение',
    5 => 'Други')
?>
