<!DOCTYPE html>
<html>
    <head>
        <title>Simple File Storage</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
    </head>
    <body>
        <div id="wrapper">
            <h1><a href="index.php">File Storage</a></h1>
            <div style="clear:both;"></div>