<div style="clear:both;"></div>
<div id="shadow">&nbsp;</div>        
</div>
</body>
</html>