<?php
$types = array ('Food','Transport','Other', 'Clothes');
?>
