<!DOCTYPE html>
<html>
    <head>
        <title>Expenses Monitoring</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
    </head>
    <body>
        <div id="wrapper">
            <h1>Expenses</h1>
            <h2>Monitoring</h2>
            <div style="clear:both;"></div>