$(document).ready(function() {
    $("#addMSG").click(function() {
        $("#postField").show();
    });
    $("#addCat").click(function() {
        $("#postCat").show();
    });
});