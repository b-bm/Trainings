<!DOCTYPE html>

<html>
	<header>
		<title><?php echo $pageTitle; ?></title>
		<meta charset="UTF-8">
	</header>
	
	<body>