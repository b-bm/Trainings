<?php
session_start();
$pageTitle = "Списък с файлове";
include('./includes/header.php');
if (isset($_SESSION['logged']) && $_SESSION['logged'] == true) {
    echo("<a href='./upload.php'>Качи файл</a>\t\t");
    ?>

    <table border="1">
        <tr>
            <th>
                Файл
            </th> 
        </tr>
        <?php
        $path = './userdata';

        if ($dir = opendir($path)) {
            while (($file = readdir($dir)) !== false) {
                if ($file === '.' || $file === '..') {
                    continue;
                }
                echo('<tr> <td> <a href="./' . $path . "/" . $file . '" > ' . $file . '</a></td>');
            }
        } else {
            echo('<div style="font-weight:bold;color:red;">Несъществуваща директория.</div>');
            echo('<div style="font-weight:bold;color:red;">Моля обърнете се към системния администратор.</div>');
            header("refresh:5;url=./");
        }
        closedir($dir);
        ?>

    </table>
    <?php
} else {
    echo('<div>Грешка!</div>');
    header("refresh:5;url=./");
}
include("./includes/footer.php");
?>