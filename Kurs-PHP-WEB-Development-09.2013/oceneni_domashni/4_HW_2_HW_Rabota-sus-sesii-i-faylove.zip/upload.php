<?php
session_start();
$pageTitle = 'Качване на файл';
include 'includes/header.php';
if (isset($_SESSION['logged']) && $_SESSION['logged'] == true) {
echo("<a href='./files.php'>Списък с файлове</a>\t");
//echo('<a href="./logout.php">Изход</a>');
if ($_FILES &&!$_FILES["file"]["error"] > 0) {
//$allowedExts = array("gif", "jpeg", "jpg", "png", "zip", "rar", "mp3");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);

if ($_FILES["file"]["error"] > 0) {
echo "Грешка: " . $_FILES["file"]["error"] . "<br>";
} else {
$path = './userdata';
if (file_exists($path . $_FILES["file"]["name"])) {
echo $_FILES["file"]["name"] . " вече съществува. ";
} else {
echo "Файл: " . $_FILES["file"]["name"] . "<br>";
//echo "Тип: " . $_FILES["file"]["type"] . "<br>";
//echo "Размер: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
if (isset($_POST['filename'])) {
   $new_name = $_POST['filename'] . "." . $extension;
} else {
   $new_name = $_FILES["file"]["name"];
}
move_uploaded_file($_FILES["file"]["name"], $path . $new_name);
echo "Файла е прехвърлен успешно.";
}
}
} else {
echo "Непозволен тип на файла.";
}

?>
<form action="" method="POST" enctype="multipart/form-data">
    <div>Име:<input type="text" name="filename" /></div>
    <div>Файл:<input type="file" name="file" /></div>
    <div><input type="submit" name="submit" value="Качи"></div>
</form>
<?php
        
    } else{
        echo('<div;">Греяка!</div>');
        header( "refresh:5;url=./" );        
    }
    include("./includes/footer.php");
?>


