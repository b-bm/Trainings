<?php
    mb_internal_encoding("UTF-8"); 
?>
<!DOCTYPE html>
<html>
    <head>
        <title><?= $pageTitle;?></title>

        <meta charset="UTF-8">       
    </head>
    <body>