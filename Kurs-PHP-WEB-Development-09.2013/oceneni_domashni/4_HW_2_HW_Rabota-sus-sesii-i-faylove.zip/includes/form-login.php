<form method="post" action="" >
    <div>Име:<input type="text" name="username" /></div>
    <div>Парола:<input type="password" name="password" /> </div>
    <div><input type="submit" name="submit" value="Влез" /></div>
    <div><a href="register.php" > Регистрирай се</a></div>
</form>