<?php
session_start();
$pageTitle = 'Вход';
include ('.\includes\header.php');
if (isset($_SESSION['logged']) && $_SESSION['logged'] == true) {
    header("refresh:5;url=files.php");
} else
if (empty($_POST['submit'])) {
    include('includes/form-login.php');
} else {
    //checks 
    $username = $_POST['username'];
    $password = $_POST['password'];
    //check for file existing
    if (file_exists('passwords.txt')) {
        $list = file('passwords.txt');
    } else {
        echo('<div style="font-weight:bold;color:red;">Възникна проблем, моля обърнете се към системния администратор.</div>');
        exit;
    }
    //check for valid strings
    $match = false;
    foreach ($list as $key => $value) {
        $columns = explode("<!>", $value);
        if ($columns[0] == $username && $columns[1] == $password) {
            $match = true;
            break;
        }
    }
    if ($match) {
        $_SESSION['logged'] = true;
        $_SESSION['username'] = $username;
        header("refresh:5;url=files.php");
    } else {
        echo('<div style="font-weight:bold;color:red;">Грешно име и/или парола!!!</div>');
        include('includes/form-login.php');
    }
}
include ('includes/footer.php');
?>



