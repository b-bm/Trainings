<?php 
	@session_start();
	require_once 'includes/header.php';
	
	if($_GET['added']) {
		if($_GET['added'] == 'true') {
			$message = 'The item '.$_GET['name'].' been added successfully!';
			$color = 'green';
		}
		else if($_GET['added'] == 'false') {
			$message = 'An error occured while trying to add to the database!';
			$color = 'red';
		}
	}
?>
	<div class="center">
		<div id="add-item">
			<div class="item-heading">
				<hgroup>
						<h1>Add item:</h1>
						<h4>Point out the details that describe the item you want to add:</h4>'
				</hgroup>
				</div>
				<div class="item-content">
					<form action="doexpense.php" id="add-form" name="add-item-form" method="POST" onsubmit="onsubmit="document.getElementById('add').disabled=true; document.getElementById('add').value='Waiting...';"">
						<div id="fields">
							<label for="name" class="block">
								<span class="pref">Name: </span>
								<input id="input-name" type="text" name="item-name" />
							</label>
							<label for="sum" class="block">
								<span class="pref">Sum: </span>
								<input id="input-sum" type="text" name="item-sum" />
							</label>
							<label for="type" class="block">
								<span class="pref">Type: </span>
								<select id="types" name="item-type">
								<?php
									foreach($groups as $key=>$value) {
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								?>
								</select>
							</label>
						</div>
						<?php echo '<p style="background: '.$color.';color: #fff; font-family: calibri; font-size: 14px; padding: 3px 10px;">'.$message.'</p>'; ?>
					<div class="buttons">
						<input id="add" type="submit" name="submit" value="Add" />
						<input id="add-new" type="button" value="Add new" />
						<a id="cancel-btn" href="index.php">Back to list</a>
					</div>
					
				</form>
			</div>
		</div>
	</div>

<?php 
	require_once 'includes/footer.php';
?>