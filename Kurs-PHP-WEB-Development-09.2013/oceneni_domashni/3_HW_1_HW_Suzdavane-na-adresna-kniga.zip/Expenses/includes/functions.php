<?php
	
	function get_groups() {
		$groupsArray = array();
		
		if(file_exists('includes/data/productcategories.txt')) {
			$product_categories = file_get_contents('includes/data/productcategories.txt');
			$groupsArray = explode('!', $product_categories);
			return $groupsArray;
		}
		else {
			return $groupsArray;
		}
	}
	
	function put_expenses($name, $sum, $type, $target) {
		
		if(file_exists($target)) {
			$date = date("m.d.y");
			$content = $date.'?'.$name.'?'.$sum.'?'.$type."\n";
			file_put_contents($target, $content, FILE_APPEND);
		}
	}
	
	
?>