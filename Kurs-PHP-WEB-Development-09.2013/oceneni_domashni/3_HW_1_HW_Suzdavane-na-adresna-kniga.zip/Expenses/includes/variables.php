<?php 
	require_once 'includes/functions.php';
	$title = "Expenses Calculator";
	$target = "includes/data/data.txt";
	$groups = get_groups();
?>