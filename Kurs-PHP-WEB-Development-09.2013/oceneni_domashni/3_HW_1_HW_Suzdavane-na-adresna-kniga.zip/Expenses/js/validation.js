(function() {

	window.onload = function() {
		
		var form = document.getElementById('add-form');
		
		form.addEventLintener('submit', function(ev) {
			ev.preventDefault();
			var fieldName = document.getElementById('input-name');
			var fieldSum = document.getElementById('input-sum');
			
			if(fieldName.value == null || fieldName.value == '' || fieldName.value.length < 4) {
				fieldName.appendChild('<div class="field-valid">Invalid name!</div>');
			}
			if(fieldSum.value < 0 || !parseFloat(fieldSum.value)) {
				fieldSum.appendChild('<div class="field-valid">Invalid sum!</div>');
			}
		}, false);
	}

})();