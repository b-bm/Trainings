<?php 	
	session_start();	
	require_once 'includes/variables.php';	
	require_once 'includes/functions.php';	
	
	if(isset($_POST['submit']) && $_POST['submit'] == 'Add') {
	
		$nameInit = trim($_POST['item-name']);	
		$name = str_replace('?', '', $nameInit);
		$name = str_replace('<', '', $nameInit);
		$sum = $_POST['item-sum'];	
		$type = $_POST['item-type'];	
		$validName = false;
		$validSum = false;
	
		//Validating the data.	
			
			if(mb_strlen($name) > 3) {
				$validName = true;
			}
			if((float)$sum && $sum > 0) {
				$validSum = true;
			} 
			
		//Inserting the data in the file.	
		if($validName) {
			if($validSum) {
				put_expenses($name, $sum, $type, $target);	
				header('location: /Expenses/add.php?added=true&valid=true&name='.$name);
			}
			else {
				header('location: /Expenses/add.php?added=false&sum=invalid');
			}
		}
		else {
			header('location: /Expenses/add.php?added=false&name=invalid');
		}
	}
?>